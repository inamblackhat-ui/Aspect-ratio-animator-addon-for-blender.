# Aspect Ratio Animator

A Blender addon that lets you animate render resolution (aspect ratio) across your timeline with smooth interpolation — something Blender cannot do natively.

## Why

Blender's render resolution is not keyframeable. This addon works around that by rendering each frame individually via a headless Blender process, setting the correct resolution before each frame.

## Installation

### Blender 4.2+ (drag and drop)
1. Download `aspect_ratio_animator.zip`
2. Drag the `.zip` directly into Blender's viewport
3. Click "OK" in the popup

### Manual
1. Edit → Preferences → Addons → Install
2. Browse to `aspect_ratio_animator.zip`
3. Enable the checkbox next to "Aspect Ratio Animator"

## Location

Properties → Output tab → Aspect Ratio Animator panel

## How to Use

1. Click **Add** to create a transition
2. Set **Start Resolution** and **End Resolution**
3. Set the **frame range** for that transition
4. Pick an **interpolation mode** (32 options)
5. Add as many transitions as you need
6. Set your **output path** and **render range**
7. Click **Render Animation**

A console window will open showing render progress. Frames are saved to your output path.

## Features

- Unlimited transitions
- 32 interpolation modes: Linear, Sine, Quad, Cubic, Quart, Quint, Expo, Circular, Back, Elastic, Bounce, Step
- Resolution presets (1080p, 4K, portrait, landscape, square, cinematic)
- Enable/disable individual transitions
- Duplicate, reorder, swap start/end
- "Set frame from playhead" and "Use scene resolution" shortcuts
- Preview resolution at current frame
- Print resolution table to console
- Fully automatic headless render — no manual command line needed

## Requirements

- Blender 4.2 or later
- Save your .blend file before rendering (addon will remind you)

## Notes

- The addon saves your .blend before rendering so the headless process gets your latest changes
- Output frames are numbered `frame_0001.png`, `frame_0002.png` etc.
- Use Blender's Video Sequence Editor or any video editor to combine frames into a video
- The `//` prefix in output path means "relative to your .blend file location"
