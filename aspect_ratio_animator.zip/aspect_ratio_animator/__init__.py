bl_info = {
    "name": "Aspect Ratio Animator",
    "author": "Your Name",
    "version": (2, 0, 0),
    "blender": (4, 0, 0),
    "location": "Properties > Output > Aspect Ratio Animator",
    "description": "Animate render resolution with keyframes and multiple interpolation modes",
    "category": "Render",
}

import bpy
import math
import subprocess
import sys
import os
import tempfile

from bpy.props import (
    IntProperty, CollectionProperty, EnumProperty,
    StringProperty, BoolProperty, FloatProperty
)
from bpy.types import PropertyGroup, Panel, Operator, UIList, Menu

# ─────────────────────────────────────────────
#  EASING MODES — all of them
# ─────────────────────────────────────────────

EASING_ITEMS = [
    # ── Linear ──
    ('LINEAR',          'Linear',           'Constant speed',                          'IPO_LINEAR',   0),
    # ── Smooth ──
    ('EASE_IN_OUT',     'Smooth (In/Out)',   'Slow start and end, fast middle',         'IPO_EASE_IN_OUT', 1),
    ('EASE_IN',         'Ease In',           'Slow start, fast end',                    'IPO_EASE_IN',  2),
    ('EASE_OUT',        'Ease Out',          'Fast start, slow end',                    'IPO_EASE_OUT', 3),
    # ── Bounce ──
    ('BOUNCE_OUT',      'Bounce Out',        'Bounces at the end like a ball dropping', 'IPO_BOUNCE',   4),
    ('BOUNCE_IN',       'Bounce In',         'Bounces at the start',                    'IPO_BOUNCE',   5),
    # ── Elastic ──
    ('ELASTIC_OUT',     'Elastic Out',       'Overshoots and oscillates at end',        'IPO_ELASTIC',  6),
    ('ELASTIC_IN',      'Elastic In',        'Oscillates at start',                     'IPO_ELASTIC',  7),
    # ── Back (overshoot) ──
    ('BACK_OUT',        'Back Out',          'Overshoots slightly then settles',        'IPO_BACK',     8),
    ('BACK_IN',         'Back In',           'Pulls back before moving forward',        'IPO_BACK',     9),
    # ── Exponential ──
    ('EXPO_IN_OUT',     'Expo In/Out',       'Very sharp acceleration curve',           'IPO_EXPO',    10),
    ('EXPO_IN',         'Expo In',           'Very slow start, explosive end',          'IPO_EXPO',    11),
    ('EXPO_OUT',        'Expo Out',          'Explosive start, very slow end',          'IPO_EXPO',    12),
    # ── Circular ──
    ('CIRC_IN_OUT',     'Circular In/Out',   'Arc-based easing both ends',              'IPO_CIRC',    13),
    ('CIRC_IN',         'Circular In',       'Arc-based slow start',                    'IPO_CIRC',    14),
    ('CIRC_OUT',        'Circular Out',      'Arc-based slow end',                      'IPO_CIRC',    15),
    # ── Sine ──
    ('SINE_IN_OUT',     'Sine In/Out',       'Gentle sine wave easing',                 'IPO_SINE',    16),
    ('SINE_IN',         'Sine In',           'Gentle sine slow start',                  'IPO_SINE',    17),
    ('SINE_OUT',        'Sine Out',          'Gentle sine slow end',                    'IPO_SINE',    18),
    # ── Quad ──
    ('QUAD_IN_OUT',     'Quad In/Out',       'Quadratic easing both ends',              'IPO_QUAD',    19),
    ('QUAD_IN',         'Quad In',           'Quadratic slow start',                    'IPO_QUAD',    20),
    ('QUAD_OUT',        'Quad Out',          'Quadratic slow end',                      'IPO_QUAD',    21),
    # ── Cubic ──
    ('CUBIC_IN_OUT',    'Cubic In/Out',      'Cubic easing both ends',                  'IPO_CUBIC',   22),
    ('CUBIC_IN',        'Cubic In',          'Cubic slow start',                        'IPO_CUBIC',   23),
    ('CUBIC_OUT',       'Cubic Out',         'Cubic slow end',                          'IPO_CUBIC',   24),
    # ── Quart ──
    ('QUART_IN_OUT',    'Quart In/Out',      'Quartic easing both ends',                'IPO_QUART',   25),
    ('QUART_IN',        'Quart In',          'Quartic slow start',                      'IPO_QUART',   26),
    ('QUART_OUT',       'Quart Out',         'Quartic slow end',                        'IPO_QUART',   27),
    # ── Quint ──
    ('QUINT_IN_OUT',    'Quint In/Out',      'Quintic easing both ends',                'IPO_QUINT',   28),
    ('QUINT_IN',        'Quint In',          'Quintic slow start',                      'IPO_QUINT',   29),
    ('QUINT_OUT',       'Quint Out',         'Quintic slow end',                        'IPO_QUINT',   30),
    # ── Step ──
    ('STEP',            'Step',              'Instant jump, no interpolation',          'IPO_CONSTANT', 31),
]

def ease(t, mode):
    t = max(0.0, min(1.0, t))

    if   mode == 'LINEAR':       return t
    elif mode == 'STEP':         return 0.0 if t < 1.0 else 1.0

    # Sine
    elif mode == 'SINE_IN':      return 1 - math.cos(t * math.pi / 2)
    elif mode == 'SINE_OUT':     return math.sin(t * math.pi / 2)
    elif mode == 'SINE_IN_OUT':  return -(math.cos(math.pi * t) - 1) / 2

    # Quad
    elif mode == 'QUAD_IN':      return t * t
    elif mode == 'QUAD_OUT':     return 1 - (1 - t) ** 2
    elif mode == 'QUAD_IN_OUT':  return 2*t*t if t < 0.5 else 1 - (-2*t+2)**2 / 2

    # Cubic
    elif mode == 'CUBIC_IN':     return t * t * t
    elif mode == 'CUBIC_OUT':    return 1 - (1 - t) ** 3
    elif mode == 'CUBIC_IN_OUT': return 4*t*t*t if t < 0.5 else 1 - (-2*t+2)**3 / 2

    # Quart
    elif mode == 'QUART_IN':     return t * t * t * t
    elif mode == 'QUART_OUT':    return 1 - (1 - t) ** 4
    elif mode == 'QUART_IN_OUT': return 8*t*t*t*t if t < 0.5 else 1 - (-2*t+2)**4 / 2

    # Quint
    elif mode == 'QUINT_IN':     return t ** 5
    elif mode == 'QUINT_OUT':    return 1 - (1 - t) ** 5
    elif mode == 'QUINT_IN_OUT': return 16*t**5 if t < 0.5 else 1 - (-2*t+2)**5 / 2

    # Expo
    elif mode == 'EXPO_IN':      return 0 if t == 0 else 2 ** (10*t - 10)
    elif mode == 'EXPO_OUT':     return 1 if t == 1 else 1 - 2 ** (-10*t)
    elif mode == 'EXPO_IN_OUT':
        if t == 0: return 0
        if t == 1: return 1
        return 2**(20*t-10)/2 if t < 0.5 else (2 - 2**(-20*t+10))/2

    # Circ
    elif mode == 'CIRC_IN':      return 1 - math.sqrt(1 - t*t)
    elif mode == 'CIRC_OUT':     return math.sqrt(1 - (t-1)**2)
    elif mode == 'CIRC_IN_OUT':
        return (1 - math.sqrt(1 - (2*t)**2)) / 2 if t < 0.5 else (math.sqrt(1 - (-2*t+2)**2) + 1) / 2

    # Back
    elif mode == 'BACK_IN':
        c = 1.70158
        return (c+1)*t*t*t - c*t*t
    elif mode == 'BACK_OUT':
        c = 1.70158
        return 1 + (c+1)*(t-1)**3 + c*(t-1)**2
    elif mode == 'BACK_IN_OUT': # not in list but kept for completeness
        c = 1.70158 * 1.525
        return ((2*t)**2*((c+1)*2*t - c))/2 if t < 0.5 else ((2*t-2)**2*((c+1)*(2*t-2)+c)+2)/2

    # Elastic
    elif mode == 'ELASTIC_IN':
        if t == 0: return 0
        if t == 1: return 1
        return -(2**(10*t-10)) * math.sin((t*10-10.75)*(2*math.pi)/3)
    elif mode == 'ELASTIC_OUT':
        if t == 0: return 0
        if t == 1: return 1
        return 2**(-10*t) * math.sin((t*10-0.75)*(2*math.pi)/3) + 1

    # Bounce
    elif mode == 'BOUNCE_OUT':
        n, d = 7.5625, 2.75
        if   t < 1/d:     return n*t*t
        elif t < 2/d:     t -= 1.5/d;   return n*t*t + 0.75
        elif t < 2.5/d:   t -= 2.25/d;  return n*t*t + 0.9375
        else:             t -= 2.625/d; return n*t*t + 0.984375
    elif mode == 'BOUNCE_IN':
        return 1 - ease(1 - t, 'BOUNCE_OUT')

    # Smoothstep fallback
    elif mode == 'EASE_IN':      return t * t
    elif mode == 'EASE_OUT':     return 1 - (1 - t) ** 2
    elif mode == 'EASE_IN_OUT':  return t * t * (3 - 2 * t)

    return t

# ─────────────────────────────────────────────
#  PROPERTY GROUPS
# ─────────────────────────────────────────────

class ARA_Transition(PropertyGroup):
    start_w:     IntProperty(name="Start W",    default=1080, min=2, max=16384)
    start_h:     IntProperty(name="Start H",    default=1920, min=2, max=16384)
    end_w:       IntProperty(name="End W",      default=1080, min=2, max=16384)
    end_h:       IntProperty(name="End H",      default=1080, min=2, max=16384)
    frame_start: IntProperty(name="Frame From", default=1,    min=0)
    frame_end:   IntProperty(name="Frame To",   default=10,   min=0)
    enabled:     BoolProperty(name="Enabled",   default=True)
    easing:      EnumProperty(
        name="Interpolation",
        description="How the resolution changes between start and end",
        items=EASING_ITEMS,
        default='LINEAR'
    )

class ARA_Settings(PropertyGroup):
    transitions:  CollectionProperty(type=ARA_Transition)
    active_index: IntProperty(default=0)
    frame_start:  IntProperty(name="Render From", default=1,   min=0)
    frame_end:    IntProperty(name="Render To",   default=250, min=0)
    output_path:  StringProperty(
        name="Output Path",
        default="//renders/frame_",
        subtype='FILE_PATH'
    )
    show_preview: BoolProperty(name="Show Curve Preview", default=True)

# ─────────────────────────────────────────────
#  RESOLUTION LOGIC
# ─────────────────────────────────────────────

def resolution_at_frame(frame, transitions):
    if not transitions:
        s = bpy.context.scene
        return s.render.resolution_x, s.render.resolution_y

    w, h = transitions[0].start_w, transitions[0].start_h

    for tr in transitions:
        if not tr.enabled:
            continue
        if frame < tr.frame_start:
            continue
        if frame >= tr.frame_end:
            w, h = tr.end_w, tr.end_h
            continue
        t  = ease((frame - tr.frame_start) / max(1, tr.frame_end - tr.frame_start), tr.easing)
        w  = int(round((tr.start_w + (tr.end_w - tr.start_w) * t) / 2) * 2)
        h  = int(round((tr.start_h + (tr.end_h - tr.start_h) * t) / 2) * 2)
        return w, h

    return w, h

# ─────────────────────────────────────────────
#  BUILD HEADLESS SCRIPT
# ─────────────────────────────────────────────

def build_headless_script(settings, blend_path):
    lines = []
    for tr in settings.transitions:
        if tr.enabled:
            lines.append(
                f"    ({tr.start_w},{tr.start_h},{tr.end_w},{tr.end_h},"
                f"{tr.frame_start},{tr.frame_end},'{tr.easing}'),"
            )
    transitions_str = "\n".join(lines)

    output = settings.output_path
    if output.startswith("//"):
        output = os.path.join(os.path.dirname(blend_path), output[2:])
    output = output.replace("\\", "\\\\")

    ease_fn = """
def ease(t, mode):
    import math
    t = max(0.0, min(1.0, t))
    if   mode == 'LINEAR':       return t
    elif mode == 'STEP':         return 0.0 if t < 1.0 else 1.0
    elif mode == 'SINE_IN':      return 1 - math.cos(t * math.pi / 2)
    elif mode == 'SINE_OUT':     return math.sin(t * math.pi / 2)
    elif mode == 'SINE_IN_OUT':  return -(math.cos(math.pi * t) - 1) / 2
    elif mode == 'QUAD_IN':      return t * t
    elif mode == 'QUAD_OUT':     return 1 - (1 - t) ** 2
    elif mode == 'QUAD_IN_OUT':  return 2*t*t if t < 0.5 else 1 - (-2*t+2)**2 / 2
    elif mode == 'CUBIC_IN':     return t ** 3
    elif mode == 'CUBIC_OUT':    return 1 - (1 - t) ** 3
    elif mode == 'CUBIC_IN_OUT': return 4*t**3 if t < 0.5 else 1 - (-2*t+2)**3 / 2
    elif mode == 'QUART_IN':     return t ** 4
    elif mode == 'QUART_OUT':    return 1 - (1 - t) ** 4
    elif mode == 'QUART_IN_OUT': return 8*t**4 if t < 0.5 else 1 - (-2*t+2)**4 / 2
    elif mode == 'QUINT_IN':     return t ** 5
    elif mode == 'QUINT_OUT':    return 1 - (1 - t) ** 5
    elif mode == 'QUINT_IN_OUT': return 16*t**5 if t < 0.5 else 1 - (-2*t+2)**5 / 2
    elif mode == 'EXPO_IN':      return 0 if t == 0 else 2 ** (10*t - 10)
    elif mode == 'EXPO_OUT':     return 1 if t == 1 else 1 - 2 ** (-10*t)
    elif mode == 'EXPO_IN_OUT':
        if t == 0: return 0
        if t == 1: return 1
        return 2**(20*t-10)/2 if t < 0.5 else (2 - 2**(-20*t+10))/2
    elif mode == 'CIRC_IN':      return 1 - math.sqrt(max(0, 1 - t*t))
    elif mode == 'CIRC_OUT':     return math.sqrt(max(0, 1 - (t-1)**2))
    elif mode == 'CIRC_IN_OUT':
        return (1 - math.sqrt(max(0,1-(2*t)**2)))/2 if t<0.5 else (math.sqrt(max(0,1-(-2*t+2)**2))+1)/2
    elif mode == 'BACK_IN':
        c=1.70158; return (c+1)*t**3 - c*t**2
    elif mode == 'BACK_OUT':
        c=1.70158; return 1+(c+1)*(t-1)**3+c*(t-1)**2
    elif mode == 'ELASTIC_IN':
        if t==0: return 0
        if t==1: return 1
        return -(2**(10*t-10))*math.sin((t*10-10.75)*(2*math.pi)/3)
    elif mode == 'ELASTIC_OUT':
        if t==0: return 0
        if t==1: return 1
        return 2**(-10*t)*math.sin((t*10-0.75)*(2*math.pi)/3)+1
    elif mode == 'BOUNCE_OUT':
        n,d=7.5625,2.75
        if   t<1/d:    return n*t*t
        elif t<2/d:    t-=1.5/d;   return n*t*t+0.75
        elif t<2.5/d:  t-=2.25/d;  return n*t*t+0.9375
        else:          t-=2.625/d; return n*t*t+0.984375
    elif mode == 'BOUNCE_IN':
        n,d=7.5625,2.75
        t=1-t
        if   t<1/d:    v=n*t*t
        elif t<2/d:    t-=1.5/d;   v=n*t*t+0.75
        elif t<2.5/d:  t-=2.25/d;  v=n*t*t+0.9375
        else:          t-=2.625/d; v=n*t*t+0.984375
        return 1-v
    elif mode == 'EASE_IN':      return t*t
    elif mode == 'EASE_OUT':     return 1-(1-t)**2
    elif mode == 'EASE_IN_OUT':  return t*t*(3-2*t)
    return t
"""

    return f"""
import bpy, math

TRANSITIONS = [
{transitions_str}
]

FRAME_START = {settings.frame_start}
FRAME_END   = {settings.frame_end}
OUTPUT_PATH = "{output}"

{ease_fn}

def resolution_at_frame(frame):
    if not TRANSITIONS:
        s = bpy.context.scene
        return s.render.resolution_x, s.render.resolution_y
    w, h = TRANSITIONS[0][0], TRANSITIONS[0][1]
    for (sw, sh, ew, eh, fs, fe, easing) in TRANSITIONS:
        if frame < fs: continue
        if frame >= fe:
            w, h = ew, eh
            continue
        t = ease((frame - fs) / max(1, fe - fs), easing)
        w = int(round((sw + (ew - sw) * t) / 2) * 2)
        h = int(round((sh + (eh - sh) * t) / 2) * 2)
        return w, h
    return w, h

scene = bpy.context.scene
for frame in range(FRAME_START, FRAME_END + 1):
    w, h = resolution_at_frame(frame)
    scene.render.resolution_x = w
    scene.render.resolution_y = h
    scene.render.filepath = OUTPUT_PATH + f"{{frame:04d}}"
    scene.frame_set(frame)
    bpy.ops.render.render(write_still=True)
    print(f"[ARA] Frame {{frame:04d}} -> {{w}}x{{h}}")

print("[ARA] All done.")
"""

# ─────────────────────────────────────────────
#  OPERATORS
# ─────────────────────────────────────────────

class ARA_OT_AddTransition(Operator):
    bl_idname = "ara.add_transition"
    bl_label  = "Add Transition"

    def execute(self, context):
        settings = context.scene.ara_settings
        tr       = settings.transitions.add()
        scene    = context.scene

        # Smart defaults: start from current scene res and current frame
        tr.start_w     = scene.render.resolution_x
        tr.start_h     = scene.render.resolution_y
        tr.end_w       = scene.render.resolution_x
        tr.end_h       = scene.render.resolution_y
        tr.frame_start = scene.frame_current
        tr.frame_end   = scene.frame_current + 10
        tr.name        = f"Transition {len(settings.transitions)}"

        settings.active_index = len(settings.transitions) - 1
        return {'FINISHED'}

class ARA_OT_RemoveTransition(Operator):
    bl_idname = "ara.remove_transition"
    bl_label  = "Remove Transition"

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if 0 <= idx < len(settings.transitions):
            settings.transitions.remove(idx)
            settings.active_index = max(0, idx - 1)
        return {'FINISHED'}

class ARA_OT_MoveUp(Operator):
    bl_idname = "ara.move_up"
    bl_label  = "Move Up"

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if idx > 0:
            settings.transitions.move(idx, idx - 1)
            settings.active_index -= 1
        return {'FINISHED'}

class ARA_OT_MoveDown(Operator):
    bl_idname = "ara.move_down"
    bl_label  = "Move Down"

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if idx < len(settings.transitions) - 1:
            settings.transitions.move(idx, idx + 1)
            settings.active_index += 1
        return {'FINISHED'}

class ARA_OT_DuplicateTransition(Operator):
    bl_idname = "ara.duplicate_transition"
    bl_label  = "Duplicate Transition"

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if 0 <= idx < len(settings.transitions):
            src = settings.transitions[idx]
            tr  = settings.transitions.add()
            tr.start_w     = src.start_w
            tr.start_h     = src.start_h
            tr.end_w       = src.end_w
            tr.end_h       = src.end_h
            tr.frame_start = src.frame_end
            tr.frame_end   = src.frame_end + (src.frame_end - src.frame_start)
            tr.easing      = src.easing
            tr.enabled     = src.enabled
            settings.active_index = len(settings.transitions) - 1
        return {'FINISHED'}

class ARA_OT_SwapResolution(Operator):
    bl_idname   = "ara.swap_resolution"
    bl_label    = "Swap Start/End"
    bl_description = "Swap start and end resolution of this transition"

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if 0 <= idx < len(settings.transitions):
            tr = settings.transitions[idx]
            tr.start_w, tr.end_w = tr.end_w, tr.start_w
            tr.start_h, tr.end_h = tr.end_h, tr.start_h
        return {'FINISHED'}

class ARA_OT_UseCurrentFrame(Operator):
    bl_idname   = "ara.use_current_frame_start"
    bl_label    = "Use Current Frame as Start"
    which:      StringProperty(default='start')

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if 0 <= idx < len(settings.transitions):
            tr = settings.transitions[idx]
            if self.which == 'start':
                tr.frame_start = context.scene.frame_current
            else:
                tr.frame_end = context.scene.frame_current
        return {'FINISHED'}

class ARA_OT_UseCurrentRes(Operator):
    bl_idname = "ara.use_current_res"
    bl_label  = "Use Current Scene Resolution"
    which:    StringProperty(default='start')

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        scene    = context.scene
        if 0 <= idx < len(settings.transitions):
            tr = settings.transitions[idx]
            if self.which == 'start':
                tr.start_w = scene.render.resolution_x
                tr.start_h = scene.render.resolution_y
            else:
                tr.end_w = scene.render.resolution_x
                tr.end_h = scene.render.resolution_y
        return {'FINISHED'}

class ARA_OT_Preview(Operator):
    bl_idname   = "ara.preview"
    bl_label    = "Preview at Current Frame"
    bl_description = "Apply resolution for current frame — lets you check the transition in viewport"

    def execute(self, context):
        scene    = context.scene
        settings = scene.ara_settings
        frame    = scene.frame_current
        trs      = list(settings.transitions)
        w, h     = resolution_at_frame(frame, trs)
        scene.render.resolution_x = w
        scene.render.resolution_y = h
        self.report({'INFO'}, f"Frame {frame} → {w}x{h}")
        return {'FINISHED'}

class ARA_OT_PreviewRange(Operator):
    bl_idname   = "ara.preview_range"
    bl_label    = "Print Resolution Table"
    bl_description = "Print resolution for every 10th frame to the console"

    def execute(self, context):
        scene    = context.scene
        settings = scene.ara_settings
        trs      = list(settings.transitions)
        print("\n[ARA] Resolution Table:")
        for f in range(settings.frame_start, settings.frame_end + 1, 10):
            w, h = resolution_at_frame(f, trs)
            print(f"  Frame {f:5d}  →  {w}x{h}")
        print("[ARA] Done.\n")
        self.report({'INFO'}, "Resolution table printed to console (Window > Toggle System Console)")
        return {'FINISHED'}

class ARA_OT_Render(Operator):
    bl_idname   = "ara.render"
    bl_label    = "Render Animation"
    bl_description = "Launch headless Blender to render with per-frame resolution changes"

    def execute(self, context):
        scene    = context.scene
        settings = scene.ara_settings

        blend_path = bpy.data.filepath
        if not blend_path:
            self.report({'ERROR'}, "Save your .blend file first!")
            return {'CANCELLED'}

        if settings.frame_end < settings.frame_start:
            self.report({'ERROR'}, "Render To must be >= Render From!")
            return {'CANCELLED'}

        # Ensure output dir exists
        output = settings.output_path
        if output.startswith("//"):
            output = os.path.join(os.path.dirname(blend_path), output[2:])
        out_dir = os.path.dirname(output)
        os.makedirs(out_dir, exist_ok=True)

        bpy.ops.wm.save_mainfile()

        script = build_headless_script(settings, blend_path)
        tmp    = tempfile.NamedTemporaryFile(
            mode='w', suffix='.py', delete=False, encoding='utf-8'
        )
        tmp.write(script)
        tmp.close()

        blender_exe = bpy.app.binary_path
        cmd = [blender_exe, "-b", blend_path, "-P", tmp.name]

        kwargs = {}
        if sys.platform == "win32":
            kwargs['creationflags'] = subprocess.CREATE_NEW_CONSOLE

        subprocess.Popen(cmd, **kwargs)
        self.report({'INFO'}, f"Rendering frames {settings.frame_start}–{settings.frame_end} in background console.")
        return {'FINISHED'}

class ARA_OT_ClearAll(Operator):
    bl_idname   = "ara.clear_all"
    bl_label    = "Clear All Transitions"
    bl_description = "Remove all transitions"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        context.scene.ara_settings.transitions.clear()
        return {'FINISHED'}

# ─────────────────────────────────────────────
#  PRESET RESOLUTIONS MENU
# ─────────────────────────────────────────────

PRESETS = [
    ("9:16 Portrait 1080p",  1080, 1920),
    ("1:1 Square 1080p",     1080, 1080),
    ("16:9 Landscape 1080p", 1920, 1080),
    ("4:3 Classic 1080p",    1440, 1080),
    ("2.39:1 Cinematic",     1920,  803),
    ("9:16 Portrait 4K",     2160, 3840),
    ("1:1 Square 4K",        3840, 3840),
    ("16:9 Landscape 4K",    3840, 2160),
    ("720p Landscape",       1280,  720),
    ("720p Portrait",         720, 1280),
]

class ARA_OT_ApplyPreset(Operator):
    bl_idname   = "ara.apply_preset"
    bl_label    = "Apply Preset"
    preset_name: StringProperty()
    which:       StringProperty(default='start')

    def execute(self, context):
        settings = context.scene.ara_settings
        idx      = settings.active_index
        if not (0 <= idx < len(settings.transitions)):
            return {'CANCELLED'}
        tr = settings.transitions[idx]
        for name, w, h in PRESETS:
            if name == self.preset_name:
                if self.which == 'start':
                    tr.start_w, tr.start_h = w, h
                else:
                    tr.end_w, tr.end_h = w, h
                break
        return {'FINISHED'}

class ARA_MT_PresetMenuStart(Menu):
    bl_idname = "ARA_MT_preset_start"
    bl_label  = "Presets"

    def draw(self, context):
        layout = self.layout
        for name, w, h in PRESETS:
            op = layout.operator("ara.apply_preset", text=f"{name}  ({w}×{h})")
            op.preset_name = name
            op.which       = 'start'

class ARA_MT_PresetMenuEnd(Menu):
    bl_idname = "ARA_MT_preset_end"
    bl_label  = "Presets"

    def draw(self, context):
        layout = self.layout
        for name, w, h in PRESETS:
            op = layout.operator("ara.apply_preset", text=f"{name}  ({w}×{h})")
            op.preset_name = name
            op.which       = 'end'

# ─────────────────────────────────────────────
#  UI LIST
# ─────────────────────────────────────────────

class ARA_UL_Transitions(UIList):
    bl_idname = "ARA_UL_transitions"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row(align=True)
        row.prop(item, "enabled", text="", icon='HIDE_OFF' if item.enabled else 'HIDE_ON')
        if item.enabled:
            row.label(
                text=f"{item.start_w}×{item.start_h}  →  {item.end_w}×{item.end_h}"
                     f"   f{item.frame_start}–{item.frame_end}   [{item.easing}]"
            )
        else:
            row.label(
                text=f"(disabled)  {item.start_w}×{item.start_h}  →  {item.end_w}×{item.end_h}",
                icon='X'
            )

# ─────────────────────────────────────────────
#  PANEL
# ─────────────────────────────────────────────

class ARA_PT_Panel(Panel):
    bl_label      = "Aspect Ratio Animator"
    bl_idname     = "ARA_PT_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context    = "output"

    def draw(self, context):
        layout   = self.layout
        settings = context.scene.ara_settings
        scene    = context.scene

        # ── Transition List ──
        box = layout.box()
        box.label(text="Resolution Transitions:", icon='MOD_LENGTH')

        box.template_list(
            "ARA_UL_transitions", "",
            settings, "transitions",
            settings, "active_index",
            rows=4
        )

        # List controls
        row = box.row(align=True)
        row.operator("ara.add_transition",       icon='ADD',        text="Add")
        row.operator("ara.remove_transition",    icon='REMOVE',     text="Remove")
        row.operator("ara.duplicate_transition", icon='DUPLICATE',  text="Duplicate")
        row.operator("ara.clear_all",            icon='TRASH',      text="Clear All")

        row2 = box.row(align=True)
        row2.operator("ara.move_up",   icon='TRIA_UP',   text="Up")
        row2.operator("ara.move_down", icon='TRIA_DOWN', text="Down")

        # ── Edit Selected Transition ──
        if settings.transitions and 0 <= settings.active_index < len(settings.transitions):
            tr  = settings.transitions[settings.active_index]
            ebox = layout.box()
            ebox.label(text=f"Edit: Transition {settings.active_index + 1}", icon='GREASEPENCIL')

            # Enabled toggle
            ebox.prop(tr, "enabled", text="Enabled")

            # Frames
            frow = ebox.row(align=True)
            frow.label(text="Frames:")
            frow.prop(tr, "frame_start", text="From")
            frow.prop(tr, "frame_end",   text="To")

            brow = ebox.row(align=True)
            op = brow.operator("ara.use_current_frame_start", text="Set From = Current Frame")
            op.which = 'start'
            op2 = brow.operator("ara.use_current_frame_start", text="Set To = Current Frame")
            op2.which = 'end'

            ebox.separator()

            # Start resolution
            sbox = ebox.box()
            sbox.label(text="Start Resolution:", icon='IMPORT')
            srow = sbox.row(align=True)
            srow.prop(tr, "start_w", text="W")
            srow.prop(tr, "start_h", text="H")
            sbrow = sbox.row(align=True)
            sbrow.menu("ARA_MT_preset_start", text="Presets", icon='COLLAPSEMENU')
            op3 = sbrow.operator("ara.use_current_res", text="Use Scene Res")
            op3.which = 'start'

            # Swap button
            ebox.operator("ara.swap_resolution", icon='ARROW_LEFTRIGHT', text="⇅ Swap Start / End")

            # End resolution
            endbox = ebox.box()
            endbox.label(text="End Resolution:", icon='EXPORT')
            erow = endbox.row(align=True)
            erow.prop(tr, "end_w", text="W")
            erow.prop(tr, "end_h", text="H")
            ebrow = endbox.row(align=True)
            ebrow.menu("ARA_MT_preset_end", text="Presets", icon='COLLAPSEMENU')
            op4 = ebrow.operator("ara.use_current_res", text="Use Scene Res")
            op4.which = 'end'

            ebox.separator()

            # Interpolation dropdown
            ibox = ebox.box()
            ibox.label(text="Interpolation Mode:", icon='IPO_BEZIER')
            ibox.prop(tr, "easing", text="")

        # ── Render Settings ──
        layout.separator()
        rbox = layout.box()
        rbox.label(text="Render Settings:", icon='RENDER_ANIMATION')
        rbox.prop(settings, "frame_start")
        rbox.prop(settings, "frame_end")
        rbox.prop(settings, "output_path")

        # Sync from scene
        srow = rbox.row(align=True)
        srow.operator("ara.sync_frame_range", text="Sync from Scene Range", icon='SCENE')

        layout.separator()

        # ── Actions ──
        abox = layout.box()
        abox.label(text="Actions:", icon='PLAY')
        abox.operator("ara.preview",       icon='HIDE_OFF',         text="Preview Resolution at Current Frame")
        abox.operator("ara.preview_range", icon='TEXT',             text="Print Resolution Table to Console")
        abox.operator("ara.render",        icon='RENDER_ANIMATION', text="Render Animation (Headless)")

class ARA_OT_SyncFrameRange(Operator):
    bl_idname   = "ara.sync_frame_range"
    bl_label    = "Sync Frame Range"

    def execute(self, context):
        scene    = context.scene
        settings = scene.ara_settings
        settings.frame_start = scene.frame_start
        settings.frame_end   = scene.frame_end
        return {'FINISHED'}

# ─────────────────────────────────────────────
#  REGISTER
# ─────────────────────────────────────────────

classes = [
    ARA_Transition,
    ARA_Settings,
    ARA_UL_Transitions,
    ARA_MT_PresetMenuStart,
    ARA_MT_PresetMenuEnd,
    ARA_OT_AddTransition,
    ARA_OT_RemoveTransition,
    ARA_OT_MoveUp,
    ARA_OT_MoveDown,
    ARA_OT_DuplicateTransition,
    ARA_OT_SwapResolution,
    ARA_OT_UseCurrentFrame,
    ARA_OT_UseCurrentRes,
    ARA_OT_ApplyPreset,
    ARA_OT_Preview,
    ARA_OT_PreviewRange,
    ARA_OT_Render,
    ARA_OT_ClearAll,
    ARA_OT_SyncFrameRange,
    ARA_PT_Panel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ara_settings = bpy.props.PointerProperty(type=ARA_Settings)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.ara_settings

if __name__ == "__main__":
    register()
